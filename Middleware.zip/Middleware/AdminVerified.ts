import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext';
import { Exception } from '@adonisjs/core/build/standalone';
import { returnResponse } from 'App/Helpers/Common';

export default class AdminVerified {
    public async handle({ auth, response }: HttpContextContract, next: () => Promise<void>) {
        try {
            if (!auth.user?.is_admin) {
                throw new Exception('This route only accessible by admin.', 401);
            }
        } catch (e) {
            return returnResponse(response, e.message, 401);
        }
        // code for middleware goes here. ABOVE THE NEXT CALL

        await next();
    }
}
