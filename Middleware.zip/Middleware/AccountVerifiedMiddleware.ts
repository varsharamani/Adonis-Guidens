// import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext';

import { Exception } from '@adonisjs/core/build/standalone';
import { returnResponse } from 'App/Helpers/Common';
import User from 'App/Models/User';

export default class AccountVerifiedMiddleware {
    public async handle({ auth, response }, next: () => Promise<void>) {
        try {
            if (!auth.user?.is_phone_verified) {
                throw new Exception('Phone number is not verified.', 401);
            }

            if (!auth.user?.is_verified) {
                throw new Exception('Account is not verified.', 401);
            }
            if (auth.user?.status === User.STATUS_INACTIVE) {
                throw new Exception(
                    'Your account has been archived. Please contact admin for assistance.',
                    401
                );
            }
        } catch (e) {
            return returnResponse(response, e.message, 401);
        }
        // code for middleware goes here. ABOVE THE NEXT CALL
        await next();
    }
}
