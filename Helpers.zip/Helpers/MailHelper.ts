import mjml from 'mjml';

export default class MailHelper {
    constructor(public html: string) {}

    public render() {
        return mjml(`<mjml>
            ${this.header()}
            <mj-body>
                <mj-section>
                    <mj-column width="100%">
                        <mj-spacer></mj-spacer>
                    </mj-column>
                </mj-section>
                <mj-section>
                    <mj-column width="100%">
                        <mj-image href="#" src="https://heart2help-assets.s3.us-east-2.amazonaws.com/heart2help-logo.png" width="105px" height="105px"></mj-image>
                    </mj-column>
                </mj-section>
                <mj-section padding-top="5px">${this.html}</mj-section>
            </mj-body>
            ${this.footer()}
        </mjml>`).html;
    }

    private header() {
        return `<mj-head>
            <mj-title>Heart2Help</mj-title>
            <mj-font name="Roboto" href="https://fonts.googleapis.com/css?family=Roboto:300,500"></mj-font>
            <mj-attributes>
                <mj-all font-family="Roboto, Helvetica, sans-serif"></mj-all>
                <mj-text font-weight="300" font-size="16px" color="#333333" line-height="24px"></mj-text>
                <mj-section padding="0px"></mj-section>
            </mj-attributes>
        </mj-head>`;
    }

    private footer() {
        return '';
    }
}
