import UserBlock from 'App/Models/UserBlock';

export async function getBlockUserList(user_id): Promise<number[]> {
    const userBlock = await UserBlock.query().where('created_by', user_id).select('user_id').exec();
    return userBlock.map((user) => user.user_id);
}

// Export the specific function you want to import in other files
module.exports = {
    getBlockUserList,
};
