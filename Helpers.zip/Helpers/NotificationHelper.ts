import Env from '@ioc:Adonis/Core/Env';
import Notification from 'App/Models/Notification';
import { isEmpty, uniqueArray } from './Common';
import User from 'App/Models/User';
import UserBlock from 'App/Models/UserBlock';
import UserCategory from 'App/Models/UserCategory';
import axios from 'axios';
import Device from 'App/Models/Device';
interface NotificationType {
    user_id: number;
    type: string;
    title: string;
    message: string;
    created_by?: number;
    refId: string;
    id: number;
}

interface PushNotification {
    event_code: string;
    event_type: string;
    event_id: number;
}

/**
 * store a notification to database
 * Admin Notifications
 **/
export async function sendNotification(type: string, model: any) {
    const notifications: NotificationType[] = [];
    switch (type) {
        case Notification.NOTIFY_POST:
            // Notify every user whose category matches the post category.
            if (!model.user) {
                await model.load('user');
            }
            if (!model.categories) {
                await model.load('categories');
            }
            // const postCategory = await PostCategory.query()
            //     .where('post_id', model.id)
            //     .select('category_id');
            const postCategory = model.categories;
            const postCategoryIds = postCategory.map((x) => x.id);
            const userBlocked = await UserBlock.query()
                .where('user_id', model.created_by)
                .orWhere('created_by', model.created_by);

            const userBlockedIds = uniqueArray([
                ...userBlocked.map((x) => x.created_by),
                ...userBlocked.map((x) => x.user_id),
            ]);

            const userCategory = await UserCategory.query()
                .whereNot('user_id', model.created_by)
                .whereIn('category_id', postCategoryIds)
                .whereNotIn('user_id', userBlockedIds);

            const usersIds = uniqueArray(userCategory.map((x) => x.user_id));
            const postCategoryTitle = postCategory.map((x) => x.title).join(', #');

            usersIds.map((x) =>
                notifications.push({
                    user_id: x,
                    refId: 'post_id',
                    title: 'New post created',
                    message: `${model.user.first_name} ${model.user.last_name} posted in #${postCategoryTitle}`,
                    type,
                    created_by: model.created_by,
                    id: model.id,
                })
            );
            // return [userBlockedIds, usersIds, notifications];
            break;
        case Notification.NOTIFY_POST_HELP:
            if (!model.post) {
                await model.load('post');
            }
            const title: string = 'New Help request received';
            const message: string = `New Help request received for post "${model.post.title}"`;

            notifications.push({
                user_id: model.requestor_id,
                refId: 'post_id',
                title: title,
                message: message,
                type,
                created_by: model.helper_id,
                id: model.post_id,
            });

            const eventType = 'helper_request_list';
            await firebaseNotification(
                title,
                message,
                {
                    event_code: getNotificationCodes(eventType),
                    event_id: model.post.id,
                    event_type: eventType,
                },
                [model.post.created_by]
            );

            break;
        case Notification.NOTIFY_DONATION:
            notifications.push({
                user_id: 0,
                title: 'New Donation',
                message: `${model.user.first_name} ${model.user.last_name} donated ${model.amount} to A Heart 2 Help`,
                type,
                refId: 'donation_id',
                created_by: model.user_id,
                id: model.id,
            });
            break;
        case Notification.NOTIFY_USER_REPORT:
            if (!model.user) {
                await model.load('user');
            }
            notifications.push({
                user_id: 0,
                title: 'User Reported',
                message: `${model.user.first_name} ${
                    model.user.last_name
                } was reported for ${JSON.parse(model.reason).join(', ')}`,
                type,
                refId: 'user_report_id',
                created_by: model.created_by,
                id: model.id,
            });
            break;
        case Notification.NOTIFY_POST_REPORT:
            if (!model.createdBy) {
                await model.load('createdBy');
            }
            if (!model.post) {
                await model.load('post');
            }
            notifications.push({
                user_id: 0,
                title: 'Post Reported',
                message: `Post "${model.post.title}" by ${model.createdBy.first_name} ${model.createdBy.last_name} was Reported for spam`,
                type,
                refId: 'post_report_id',
                created_by: model.created_by,
                id: model.id,
            });
            // send notification to post owner
            notifications.push({
                user_id: model.post.created_by,
                title: 'Post Reported',
                message: `POST REPORTED for ${JSON.parse(model.type).join(', ')} "${model.reason}"`,
                type,
                refId: 'post_report_id',
                created_by: model.created_by,
                id: model.id,
            });
            break;
        case Notification.NOTIFY_POST_EXPIRED:
            // send notification to post owner
            notifications.push({
                user_id: model.created_by,
                title: 'Post expired',
                message: `${model.title} has been expired`,
                type,
                refId: 'post_id',
                created_by: model.created_by,
                id: model.id,
            });
            break;
        default:
            break;
    }
    if (isEmpty(notifications)) {
        // throw new Error('invalid notification type');
    } else {
        for (const notification of notifications) {
            await storeNotificationToDB(notification);
        }
    }
}

export function getNotificationCodes(notificationType: string) {
    let code = '';
    switch (notificationType) {
        case 'helper_request_list':
            code = 'help_001';
            break;

        case 'view_post':
            code = 'post_001';
            break;

        default:
            break;
    }
    return code;
}

async function storeNotificationToDB(data: NotificationType) {
    // send notification to all admins if user_id is zero
    if (data.user_id === 0) {
        const users = await User.query().where('is_admin', true).where('status', 'active');
        if (users) {
            await Promise.all(
                users.map(
                    async (user) =>
                        await user.related('notifications').create({
                            title: data.title,
                            message: data.message,
                            type: data.type,
                            created_by: data.created_by,
                            [data.refId]: data.id,
                        })
                )
            );
        }
    } else {
        await Notification.create({
            user_id: data.user_id,
            title: data.title,
            message: data.message,
            type: data.type,
            created_by: data.created_by,
            [data.refId]: data.id,
        });
    }
}

export async function firebaseNotification(
    title: string,
    message: string,
    data: PushNotification,
    user_ids: number[]
): Promise<boolean> {
    try {
        const firebaseKey: string = Env.get('FIREBASE_KEY');
        const fcmUrl = 'https://fcm.googleapis.com/fcm/send';
        const header = {
            'Content-Type': 'application/json',
            'Authorization': 'key=' + firebaseKey,
        };

        const devices = await Device.query()
            .whereIn('user_id', user_ids)
            .distinct('fcm_token')
            .exec();
        const fcmTokens = devices.map((device) => {
            return device.fcm_token;
        });

        data['click_action'] = 'FLUTTER_NOTIFICATION_CLICK';
        const fcmNotification = {
            data: data,
            notification: {
                body: message,
                title: !isEmpty(title) ? title : 'Heart2Help',
                badge: '1',
                sound: 'default',
            },
            registration_ids: fcmTokens,
            content_available: true,
            priority: 'high',
        };

        if (fcmTokens.length > 0) {
            await axios.post(fcmUrl, fcmNotification, {
                headers: header,
            });
        }

        return true;
    } catch (error) {
        return false;
    }
}

// Export the specific function you want to import in other files
module.exports = {
    sendNotification,
    getNotificationCodes,
    firebaseNotification,
};
