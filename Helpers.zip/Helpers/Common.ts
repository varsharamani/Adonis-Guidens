import { string } from '@ioc:Adonis/Core/Helpers';
import Env from '@ioc:Adonis/Core/Env';
import { DateTime } from 'luxon';
import Drive from '@ioc:Adonis/Core/Drive';
import { Twilio } from 'twilio';
import { Client } from '@googlemaps/google-maps-services-js';
import { googleMapApiKey } from 'Config/app';
import heicConvert from 'heic-convert';
import sharp from 'sharp';
import fs from 'fs';
import https from 'https';
import http from 'http';
/************************/
// global function to check the satisfiable conditions
/************************/

export function isEmpty(value): boolean {
    return (
        value === undefined ||
        value === null ||
        value === '' ||
        (typeof value === 'boolean' && !value) ||
        (typeof value === 'number' && value === 0) ||
        (Array.isArray(value) && value.length === 0) ||
        (typeof value === 'object' && Object.keys(value).length === 0)
    );
}

export function uniqueArray(arr: any[]): any[] {
    return arr.filter((value, index, self) => self.indexOf(value) === index);
}

/************************/
/*
@param response is response contact.
@param status indicates status code.
*/
/************************/
export function returnResponse(
    response,
    message: string,
    status: number = 200,
    data = {},
    errors: Array<any> | null = null
) {
    let isSuccess = true;
    if (![200, 201, 202, 203].includes(status)) {
        isSuccess = false;
    }

    return response.status(status).json({
        is_success: isSuccess,
        status: status,
        message: message,
        data: data,
        errors: errors,
    });
}

// get random digits
export function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// get datetime string with specific timezone.
export function getDateTime(dateTime: DateTime, timezone: string = '') {
    if (!timezone) {
        timezone = Env.get('TZ');
    }

    return dateTime.setZone(timezone).toLocaleString({
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
    });
}

export async function download(url: string, dest: string, fileName: string) {
    if (!url) {
        return false;
    }
    const TIMEOUT = 12000;
    const uri = new URL(url);
    const pkg = url.toLowerCase().startsWith('https:') ? https : http;

    return new Promise<boolean>((resolve, reject) => {
        const request = pkg.get(uri.href).on('response', (res) => {
            if (res.statusCode === 200) {
                if (!fs.existsSync(dest)) {
                    fs.mkdirSync(dest, { recursive: true });
                }
                const file = fs.createWriteStream(dest + fileName);
                res.on('end', () => {
                    file.end();
                    // console.log(`${uri.pathname} downloaded to: ${path}`)
                    resolve(true);
                })
                    .on('error', (err) => {
                        // console.log('Error downloading');

                        file.destroy();
                        fs.unlink(dest + fileName, () => reject(err));
                    })
                    .pipe(file);
                // after download completed close filestream
                file.on('finish', () => {
                    file.close();
                    // console.log('Download Completed');
                });
            } else if (res.statusCode === 302 || res.statusCode === 301) {
                // Recursively follow redirects, only a 200 will resolve.
                download(res.headers.location as string, dest, fileName).then(() => resolve(true));
            } else {
                reject(
                    new Error(
                        `Download request failed, response status: ${res.statusCode} ${res.statusMessage}`
                    )
                );
            }
        });
        request.setTimeout(TIMEOUT, function () {
            request.abort();
            reject(new Error(`Request timeout after ${TIMEOUT / 1000.0}s`));
        });
    });
}

export async function fileUpload(file: any, dir = 'images'): Promise<object> {
    if (file) {
        const timestamp = new Date().getTime();
        let fileName = `${string.generateRandom(10)}-${timestamp}.${file.extname}`;
        let filePath: string = `${dir}/${fileName}`;
        let contentType = file.type + '/' + file.subtype;

        // save file to local disk
        await file.moveToDisk(dir, { name: fileName }, 'local');

        const localDrive = Drive.use('local');

        if (file.extname.toLowerCase() === 'heic') {
            const outputFileName = `${string.generateRandom(10)}-${timestamp}.jpeg`;
            const outputFilePath = `${dir}/${outputFileName}`;

            // get image from local disk
            const inputBuffer = await localDrive.get(filePath);
            // convert image to jpeg format
            const outputBuffer = await heicConvert({
                buffer: inputBuffer, // the HEIC file buffer
                format: 'JPEG', // output format
            });
            // put converted image to local disk
            await localDrive.put(outputFilePath, outputBuffer as unknown as string);
            await localDrive.delete(filePath);
            // delete original image from local disk
            filePath = outputFilePath;
            fileName = outputFileName;
            contentType = 'image/jpeg';
        }
        // // resize image to 720 width
        // const bufferData = await sharp(localDrive.makePath(filePath)).resize(720).toBuffer();
        // // put image to s3 drive
        // await Drive.put(filePath, bufferData as unknown as string, {
        //     visibility: 'private',
        //     contentType,
        // });
        // // delete image from local disk
        // await localDrive.delete(filePath);
        await resizeAndMoveToDisk(filePath, contentType);
        // await file.moveToDisk(dir, { name: fileName });
        return { filePath: filePath, fileName: fileName };
    }
    return { filePath: null, fileName: null };
}

// convert local file and upload to disk
export async function resizeAndMoveToDisk(filePath: string, contentType: string) {
    const localDrive = Drive.use('local');
    // resize image to 720 width
    const bufferData = await sharp(localDrive.makePath(filePath)).resize(720).toBuffer();
    // put image to s3 drive
    await Drive.put(filePath, bufferData as unknown as string, {
        visibility: 'private',
        contentType,
    });
    // delete image from local disk
    await localDrive.delete(filePath);
}

export async function getFileUrl(filePath: string): Promise<string | null> {
    try {
        return await Drive.getSignedUrl(filePath, {
            expiresIn: '60mins',
        });
    } catch (error) {
        return null;
    }
}

// universal image extensions
export function getImageExtensions(): string[] {
    // this will done due to adonis js fileExts is case sensitive.
    const exts = Env.get('IMAGE_EXTENSIONS').split(',');
    const upperExts = exts.map((str: string) => str.toUpperCase());
    const mergedExtensions: string[] = [];

    for (let i = 0; i < exts.length; i++) {
        mergedExtensions.push(exts[i]);
        mergedExtensions.push(upperExts[i]);
    }

    return mergedExtensions;
}

// universal image size
export function getImageSize() {
    return Env.get('IMAGE_SIZE') ?? '10mb';
}

export function getMaskEmail(email: string): string {
    // Split the email address into local part and domain
    const [localPart, domain] = email.split('@');

    // Get the first two characters of the local part
    const firstTwoChars = localPart.slice(0, 2);

    // Create a masked local part with asterisks, preserving the first two characters
    const maskedLocalPart = `${firstTwoChars}${'*'.repeat(localPart.length - 2)}${localPart.slice(
        localPart.length
    )}`;

    // Combine the masked local part and the domain with the "@" symbol
    return `${maskedLocalPart}@${domain}`;
}

// send sms via twilio.
export async function sendTwilioSms(phone: string, message: string): Promise<any> {
    try {
        if (Env.get('NODE_ENV') === 'production') {
            const twilio = new Twilio(Env.get('TWILIO_ACCOUNT_SID'), Env.get('TWILIO_AUTH_TOKEN'));
            await twilio.messages.create({
                body: message,
                to: phone,
                from: Env.get('TWILIO_PHONE_NUMBER'), // From a valid Twilio number
            });
        }

        return {
            is_success: true,
            message: 'message has been sent.',
        };
    } catch (error) {
        return {
            is_success: false,
            message: error.message,
        };
    }
}

export function maskPhoneNumber(phoneNumber, visibleDigits = 4): string {
    // Remove all non-digit characters from the phone number
    const cleanedPhoneNumber = phoneNumber.replace(/\D/g, '');

    // Calculate the number of asterisks required
    const asterisks = '*'.repeat(cleanedPhoneNumber.length - visibleDigits);

    // Extract and keep the last 'visibleDigits' characters
    const visiblePart = cleanedPhoneNumber.slice(-visibleDigits);

    // Combine the asterisks and visible part
    return `${asterisks}${visiblePart}`;
}

export function formatPhoneNumber(phoneNumberString: string) {
    var cleaned = ('' + phoneNumberString).replace(/\D/g, '');
    var match = cleaned.match(/^(\d|)?(\d{3})(\d{3})(\d{4})$/);
    if (match) {
        // var intlCode = match[1] ? `+${match[1]} ` : '';
        return ['(', match[2], ') ', match[3], '-', match[4]].join('');
    }
    return '';
}

/************************/
// global function to get location information
/************************/
export function getLocationInfo(lat: number, lng: number) {
    const client = new Client({});

    client
        .elevation({
            params: {
                locations: [{ lat, lng }],
                key: googleMapApiKey,
            },
            timeout: 1000, // milliseconds
        })
        .then((r) => {
            console.log(r.data.results[0].elevation);
        })
        .catch((e) => {
            console.log(e.response.data.error_message);
        });
}

// Export the specific function you want to import in other files
module.exports = {
    isEmpty,
    uniqueArray,
    returnResponse,
    getRandomInt,
    getDateTime,
    fileUpload,
    getFileUrl,
    getMaskEmail,
    maskPhoneNumber,
    getImageExtensions,
    getImageSize,
    sendTwilioSms,
    getLocationInfo,
    formatPhoneNumber,
    download,
    resizeAndMoveToDisk,
};
