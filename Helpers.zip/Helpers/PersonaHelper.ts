import Env from '@ioc:Adonis/Core/Env';
import User from 'App/Models/User';
import axios from 'axios';
import { isEmpty } from './Common';
export default class Persona {
    public static headers = {
        'accept': 'application/json',
        'Persona-Version': '2023-01-05',
        'content-type': 'application/json',
        'authorization': 'Bearer ' + Env.get('PERSONA_KEY', ''),
    };

    public static createAccount(user: User): Promise<any> {
        const options = {
            method: 'POST',
            url: 'https://withpersona.com/api/v1/accounts',
            headers: this.headers,
            data: {
                data: {
                    attributes: {
                        'reference-id': user.id + '',
                        'name-first': user.first_name,
                        'name-last': user.last_name,
                        'birthdate': user.dob ?? '',
                        'email-address': user.email,
                        'phone-number': user.phone_number,
                    },
                },
            },
        };

        return new Promise((resolve, reject) => {
            axios
                .request(options)
                .then(async function (response) {
                    user.persona_id = response.data.data.id;
                    await user.save();
                    console.log(response.data.data);
                    resolve(response.data);
                })
                .catch(function (error) {
                    console.error(error.response.data);
                    reject(error);
                });
        });
    }

    public static updateAccount(user: User) {
        if (isEmpty(user.persona_id)) {
            return null;
        }
        const options = {
            method: 'PATCH',
            url: 'https://withpersona.com/api/v1/accounts/' + user.persona_id,
            headers: this.headers,
            data: {
                data: {
                    attributes: {
                        'reference-id': user.id + '',
                        'name-first': user.first_name,
                        'name-last': user.last_name,
                        'birthdate': user.dob ?? '',
                        'email-address': user.email,
                        'phone-number': user.phone_number,
                    },
                },
            },
        };

        return new Promise((resolve, reject) => {
            axios
                .request(options)
                .then(function (response) {
                    console.log(response.data);
                    resolve(response.data);
                })
                .catch(function (error) {
                    console.error(error.response.data);
                    reject(error);
                });
        });
    }

    public static createAnInquiry(user: User): Promise<any> {
        const options = {
            method: 'POST',
            url: 'https://withpersona.com/api/v1/inquiries',
            headers: this.headers,
            data: {
                data: {
                    attributes: {
                        'inquiry-template-id': Env.get('PERSONA_INQUIRY_TEMPLATE'),
                        'account-id': user.persona_id,
                        'note': user.id + '',
                    },
                },
            },
        };

        return new Promise((resolve, reject) => {
            axios
                .request(options)
                .then(function (response) {
                    console.log(response.data);
                    resolve(response.data);
                })
                .catch(function (error) {
                    console.error(error.response.data);
                    reject(error);
                });
        });
    }

    public static resumeAnInquiry(inquiry_id: string): Promise<any> {
        const options = {
            method: 'POST',
            url: 'https://withpersona.com/api/v1/inquiries/' + inquiry_id + '/resume',
            headers: this.headers,
        };

        return new Promise((resolve, reject) => {
            axios
                .request(options)
                .then(function (response) {
                    console.log(response.data);
                    resolve(response.data);
                })
                .catch(function (error) {
                    console.error(error.response.data);
                    reject(error);
                });
        });
    }

    public static generateAOneTimeLink(inquiry_id: string): Promise<any> {
        const options = {
            method: 'POST',
            url:
                'https://withpersona.com/api/v1/inquiries/' +
                inquiry_id +
                '/generate-one-time-link',
            headers: this.headers,
        };

        return new Promise((resolve, reject) => {
            axios
                .request(options)
                .then(function (response) {
                    console.log(response.data);
                    resolve(response.data);
                })
                .catch(function (error) {
                    console.error(error.response.data);
                    reject(error);
                });
        });
    }
}
